<div class="w-75 mx-auto mt-5 text-white">
<div class="mt-3 mb-3"><i style="color: white;" class="fas fa-4x fa-hand-holding-usd"></i></div>
<div class="mt-4 mb-5">ForAlexa is a free platform and you can help keep it that way</div>		

<a href="https://www.paypal.com/donate?hosted_button_id=YFLYA566BEQCE" class="btn btn-success btn-lg btn-block mt-5 mb-5" role="button" aria-pressed="true" target="_blank"  style="color: black;"><i class="fab fa-2x fa-cc-paypal fa-2x" style="color: black;"></i> Donate in Real (R$)</a>	
	
<a href="https://www.paypal.com/donate?hosted_button_id=LPPAD8287DZKA" class="btn btn-info btn-lg btn-block mt-5 mb-5" role="button" aria-pressed="true" target="_blank"  style="color: black;"> <i class="fab fa-2x fa-cc-paypal fa-2x" style="color: black;"></i> Donate in Dollar (USD)</a>	
	
</div>