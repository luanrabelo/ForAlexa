<div class="text-center text-white mx-auto mt-5">
<div><h4>Page not found</h4></div>	
<img src="https://i.pinimg.com/originals/ab/0a/6b/ab0a6b2a24e43b2e675095a14cdf8479.gif" width="75%" height="75%">
</div>