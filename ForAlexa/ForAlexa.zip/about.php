<div class="text-white w-75 mx-auto text-center mt-5" style="letter-spacing: 2px; font-size: 20px;">
<div class="mt-5 mb-5"><h1>ForAlexa</h1></div>
<div>ForAlexa is a web online form to help designing Alexa skill for teaching</div>
<div class="mt-5 mb-5">
<div>Luan Rabelo</div>
<small class="text-muted">Developer</small>
</div>
<hr class="text-center" width="50%" style="border: 1.5px solid black;">
<div class="mt-5 mb-5">
<div>Marcelo Vallinoto</div>
<small class="text-muted">Developer / Collaborator</small>
</div>

</div>